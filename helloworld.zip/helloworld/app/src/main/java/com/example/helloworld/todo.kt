package com.example.helloworld

public class todo {
    var title = ""
    var done = false
}