package com.example.helloworld

public class todoAdapter {
    val entrees = mutableListOf<String>() // so can add stuff


}