// This app counts the number of times the button was clicked and also serves as todo list.

package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    // max list size 10
    private lateinit var list_board : RecyclerView
    private lateinit var TodoAdapter : todoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list_board = findViewById(R.id.list_board)
        list_board.adapter = TodoAdapter

        val button = findViewById<Button>(R.id.addButton) // adds list item
        button.setOnClickListener {
            Toast.makeText(this, "added!!", Toast.LENGTH_SHORT).show()
          //  val viewA = layoutInflater.inflate(R.layout.list_board, null)
        }

        val button2 = findViewById<Button>(R.id.helloButton).setOnClickListener {
        }

    }

}
